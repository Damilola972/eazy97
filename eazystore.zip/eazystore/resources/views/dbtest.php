<?php
$conn = mysqli_connect(
  "sql100.infinityfree.com", // host
  "if0_39474953",            // username
  "Damilola972",             // password
  "if0_39474953_laravel"     // database
);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully!";
?>